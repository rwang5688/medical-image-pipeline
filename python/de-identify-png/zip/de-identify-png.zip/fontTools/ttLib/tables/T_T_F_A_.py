from . import asciiTable


class table_T_T_F_A_(asciiTable.asciiTable):
    pass
